#!/bin/bash

libwyliodrin_version=$(wylio -v) sudo -E mocha test.js --no-timeouts