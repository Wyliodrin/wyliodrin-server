To run demo:
  * start redis-server
  * run ``make sim_board`` in one terminal
  * run ``make sim_owner`` is another terminal
