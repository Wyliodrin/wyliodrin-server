* General
  * [0] wtalk, libwyliodrin and hypervisor version at startup
  * [0] XMPP jid and owner
  * [0] XMPP connection status
  * [0] Owner is online / offline
  * [0] Every 10 pings
  * [0] Disconnect

* Shells
  * [0] Shells logs are sent by hypervisor

* Fuse
  * [0] Whether fuse is available or not
  * [0] Everything except file content

* Task Manager
  * [0] request and response

* Make
  * [0] What project is built

* Communication
  * Every 100 logs
