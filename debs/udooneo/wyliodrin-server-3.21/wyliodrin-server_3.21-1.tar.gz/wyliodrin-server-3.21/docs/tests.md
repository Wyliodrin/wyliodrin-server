* Teste conectare
  * [1] test conectare
  * [1] versiuni dupa conectare (wtalk primeste versiunea din variabila de mediu)
  * [1] test fisier json gresit -> vad un error log (daca json-ul e gresit nu vad jid)
  * [1] test conectare esuata
  * [1] test incercare reconectare
  * [1] test deconectare server xmpp
  * [1] test deconectare / reconectare xmpp

* Test FUSE
  * [0] server trimite stanza de build, se verifica cererile de fuse + log
  * [0] se creeaza directoare cu fisiere corecte / gresite
  * [0] pretty much everything
  * [0] stress test
  * [0] build no fuse

* Test shell
  * [1] open / close
  * [1] disconnect / reconnect XMPP server
  * [0] se verifica cu fisiere (ls / mkdir / etc)
  * [0] se verifica daca proiectul functioneaza (prin contorizarea testelor)
