*************
JSON handling
*************

.. highlight:: c

The configuration files and most of the protocols use JSON for communication.
``wyliodrin-server`` uses the libjansson_ library for JSON handling.



.. _libjansson: https://jansson.readthedocs.org/en/latest/index.html
