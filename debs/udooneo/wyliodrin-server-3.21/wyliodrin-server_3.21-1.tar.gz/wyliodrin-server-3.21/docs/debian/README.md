# UDOO

**NOTE**: _modify **cmake_minimum_required (VERSION 2.8.8)** to **cmake_minimum_required (VERSION 2.8.7)** in **CMakeLists.txt** and **hypervisor/CMakeLists.txt**_

```
git clone https://github.com/Wyliodrin/wyliodrin-server.git wyliodrin-server-3.21
git checkout v3.21
DEBFULLNAME="Razvan MATEI" EMAIL="matei.rm94@gmail.com" DEBEMAIL="matei.rm94@gmail.com" dh_make -e matei.rm94@gmail.com -c gpl2 --createorig
```