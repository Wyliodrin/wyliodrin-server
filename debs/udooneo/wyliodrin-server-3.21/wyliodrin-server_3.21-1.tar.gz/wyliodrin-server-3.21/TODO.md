<!---
Use :white_medium_square: for TODO
Use :white_check_mark: for DONE
-->

# v3.21
- :white_check_mark: get version in hypervisor's CMakeLists.txt from parent directory
- :white_check_mark: fix segmentation fault when /etc/wyliodrin/boardtype does not exist
- :white_check_mark: for Edison, create libwyliodrin.so and libevent.so links in order for ld to find them

# v3.22
- :white_medium_square: log file auto-redimension
