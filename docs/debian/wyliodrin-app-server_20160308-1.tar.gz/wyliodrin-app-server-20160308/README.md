Wyliodrin App Server
====================

Server app for connecting to Wyliodrin App.

Install
-------

    git cone https://github.com/Wyliodrin/wyliodrin-app-server.git
    cd wyliodrin-app-server
    npm install
    node startup
    
Please make sure you have the Wyliodrin SD card image

