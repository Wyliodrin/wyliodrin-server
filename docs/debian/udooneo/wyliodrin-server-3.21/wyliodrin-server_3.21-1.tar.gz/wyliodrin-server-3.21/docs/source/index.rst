wyliodrin-server Documentation
==============================

This is the documentation for wyliodrin-server, last updated |today|.

Contents
--------

.. toctree::
   :maxdepth: 1

   gettingstarted
   xmpphandling
   jsonhandling
   shellsmodule
   filesmodule
   makemodule
   psmodule
   communicationmodule
   signalshandling
   logshandling


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
