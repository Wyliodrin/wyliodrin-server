To build the documentation, invoke

```
make html
```

Then point your browser to build/html/index.html.
